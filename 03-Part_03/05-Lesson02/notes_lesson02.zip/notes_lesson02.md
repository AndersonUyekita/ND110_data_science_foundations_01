
# Python for Data Analysis `Lesson02`

#### Tags
* Título: _Case Study 01_
* Autor: AH Uyekita
* Data: 08/12/2018
* Cod: ND110

## Pratice

This is a pratice to learn doing a casa study.

## Python Requeriments

Packages used to perform this study.


```python
# Importing Libraries
import pandas as pd

import numpy as np   # Used to create a new column
import seaborn as sns
import matplotlib as plt

import matplotlib.pyplot as plt
% matplotlib inline
```

## Loading files

Both archives were `.csv`files so I can load using the `.read_csv()` function from the pandas libray. Keep in mind that this files uses the **semi-colon** as delimiter.


```python
# Load the red wine dataset
red = pd.read_csv('winequality-red.csv', sep = ";")

# Load the red wine dataset
white = pd.read_csv('winequality-white.csv', sep = ";")
```

## Data Structure

These two files has:

* Red Wine
    * 1599 rows or obsevations
    * 12 features
* White Wine
    * 4898 rows or observations
    * 12 features


```python
[red.shape,white.shape]
```




    [(1599, 12), (4898, 12)]



### Head

The first 10 rows of each dataset.


```python
# Head of 
red.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7.4</td>
      <td>0.70</td>
      <td>0.00</td>
      <td>1.9</td>
      <td>0.076</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>0.9978</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>7.8</td>
      <td>0.88</td>
      <td>0.00</td>
      <td>2.6</td>
      <td>0.098</td>
      <td>25.0</td>
      <td>67.0</td>
      <td>0.9968</td>
      <td>3.20</td>
      <td>0.68</td>
      <td>9.8</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>7.8</td>
      <td>0.76</td>
      <td>0.04</td>
      <td>2.3</td>
      <td>0.092</td>
      <td>15.0</td>
      <td>54.0</td>
      <td>0.9970</td>
      <td>3.26</td>
      <td>0.65</td>
      <td>9.8</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11.2</td>
      <td>0.28</td>
      <td>0.56</td>
      <td>1.9</td>
      <td>0.075</td>
      <td>17.0</td>
      <td>60.0</td>
      <td>0.9980</td>
      <td>3.16</td>
      <td>0.58</td>
      <td>9.8</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.4</td>
      <td>0.70</td>
      <td>0.00</td>
      <td>1.9</td>
      <td>0.076</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>0.9978</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>7.4</td>
      <td>0.66</td>
      <td>0.00</td>
      <td>1.8</td>
      <td>0.075</td>
      <td>13.0</td>
      <td>40.0</td>
      <td>0.9978</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7.9</td>
      <td>0.60</td>
      <td>0.06</td>
      <td>1.6</td>
      <td>0.069</td>
      <td>15.0</td>
      <td>59.0</td>
      <td>0.9964</td>
      <td>3.30</td>
      <td>0.46</td>
      <td>9.4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7.3</td>
      <td>0.65</td>
      <td>0.00</td>
      <td>1.2</td>
      <td>0.065</td>
      <td>15.0</td>
      <td>21.0</td>
      <td>0.9946</td>
      <td>3.39</td>
      <td>0.47</td>
      <td>10.0</td>
      <td>7</td>
    </tr>
    <tr>
      <th>8</th>
      <td>7.8</td>
      <td>0.58</td>
      <td>0.02</td>
      <td>2.0</td>
      <td>0.073</td>
      <td>9.0</td>
      <td>18.0</td>
      <td>0.9968</td>
      <td>3.36</td>
      <td>0.57</td>
      <td>9.5</td>
      <td>7</td>
    </tr>
    <tr>
      <th>9</th>
      <td>7.5</td>
      <td>0.50</td>
      <td>0.36</td>
      <td>6.1</td>
      <td>0.071</td>
      <td>17.0</td>
      <td>102.0</td>
      <td>0.9978</td>
      <td>3.35</td>
      <td>0.80</td>
      <td>10.5</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
white.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7.0</td>
      <td>0.27</td>
      <td>0.36</td>
      <td>20.7</td>
      <td>0.045</td>
      <td>45.0</td>
      <td>170.0</td>
      <td>1.0010</td>
      <td>3.00</td>
      <td>0.45</td>
      <td>8.8</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6.3</td>
      <td>0.30</td>
      <td>0.34</td>
      <td>1.6</td>
      <td>0.049</td>
      <td>14.0</td>
      <td>132.0</td>
      <td>0.9940</td>
      <td>3.30</td>
      <td>0.49</td>
      <td>9.5</td>
      <td>6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8.1</td>
      <td>0.28</td>
      <td>0.40</td>
      <td>6.9</td>
      <td>0.050</td>
      <td>30.0</td>
      <td>97.0</td>
      <td>0.9951</td>
      <td>3.26</td>
      <td>0.44</td>
      <td>10.1</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7.2</td>
      <td>0.23</td>
      <td>0.32</td>
      <td>8.5</td>
      <td>0.058</td>
      <td>47.0</td>
      <td>186.0</td>
      <td>0.9956</td>
      <td>3.19</td>
      <td>0.40</td>
      <td>9.9</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.2</td>
      <td>0.23</td>
      <td>0.32</td>
      <td>8.5</td>
      <td>0.058</td>
      <td>47.0</td>
      <td>186.0</td>
      <td>0.9956</td>
      <td>3.19</td>
      <td>0.40</td>
      <td>9.9</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>



### Tails

The last 10 rows of each dataset.


```python
red.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1589</th>
      <td>6.6</td>
      <td>0.725</td>
      <td>0.20</td>
      <td>7.8</td>
      <td>0.073</td>
      <td>29.0</td>
      <td>79.0</td>
      <td>0.99770</td>
      <td>3.29</td>
      <td>0.54</td>
      <td>9.2</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1590</th>
      <td>6.3</td>
      <td>0.550</td>
      <td>0.15</td>
      <td>1.8</td>
      <td>0.077</td>
      <td>26.0</td>
      <td>35.0</td>
      <td>0.99314</td>
      <td>3.32</td>
      <td>0.82</td>
      <td>11.6</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1591</th>
      <td>5.4</td>
      <td>0.740</td>
      <td>0.09</td>
      <td>1.7</td>
      <td>0.089</td>
      <td>16.0</td>
      <td>26.0</td>
      <td>0.99402</td>
      <td>3.67</td>
      <td>0.56</td>
      <td>11.6</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1592</th>
      <td>6.3</td>
      <td>0.510</td>
      <td>0.13</td>
      <td>2.3</td>
      <td>0.076</td>
      <td>29.0</td>
      <td>40.0</td>
      <td>0.99574</td>
      <td>3.42</td>
      <td>0.75</td>
      <td>11.0</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1593</th>
      <td>6.8</td>
      <td>0.620</td>
      <td>0.08</td>
      <td>1.9</td>
      <td>0.068</td>
      <td>28.0</td>
      <td>38.0</td>
      <td>0.99651</td>
      <td>3.42</td>
      <td>0.82</td>
      <td>9.5</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1594</th>
      <td>6.2</td>
      <td>0.600</td>
      <td>0.08</td>
      <td>2.0</td>
      <td>0.090</td>
      <td>32.0</td>
      <td>44.0</td>
      <td>0.99490</td>
      <td>3.45</td>
      <td>0.58</td>
      <td>10.5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1595</th>
      <td>5.9</td>
      <td>0.550</td>
      <td>0.10</td>
      <td>2.2</td>
      <td>0.062</td>
      <td>39.0</td>
      <td>51.0</td>
      <td>0.99512</td>
      <td>3.52</td>
      <td>0.76</td>
      <td>11.2</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1596</th>
      <td>6.3</td>
      <td>0.510</td>
      <td>0.13</td>
      <td>2.3</td>
      <td>0.076</td>
      <td>29.0</td>
      <td>40.0</td>
      <td>0.99574</td>
      <td>3.42</td>
      <td>0.75</td>
      <td>11.0</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1597</th>
      <td>5.9</td>
      <td>0.645</td>
      <td>0.12</td>
      <td>2.0</td>
      <td>0.075</td>
      <td>32.0</td>
      <td>44.0</td>
      <td>0.99547</td>
      <td>3.57</td>
      <td>0.71</td>
      <td>10.2</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1598</th>
      <td>6.0</td>
      <td>0.310</td>
      <td>0.47</td>
      <td>3.6</td>
      <td>0.067</td>
      <td>18.0</td>
      <td>42.0</td>
      <td>0.99549</td>
      <td>3.39</td>
      <td>0.66</td>
      <td>11.0</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python
white.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4888</th>
      <td>6.8</td>
      <td>0.220</td>
      <td>0.36</td>
      <td>1.20</td>
      <td>0.052</td>
      <td>38.0</td>
      <td>127.0</td>
      <td>0.99330</td>
      <td>3.04</td>
      <td>0.54</td>
      <td>9.2</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4889</th>
      <td>4.9</td>
      <td>0.235</td>
      <td>0.27</td>
      <td>11.75</td>
      <td>0.030</td>
      <td>34.0</td>
      <td>118.0</td>
      <td>0.99540</td>
      <td>3.07</td>
      <td>0.50</td>
      <td>9.4</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4890</th>
      <td>6.1</td>
      <td>0.340</td>
      <td>0.29</td>
      <td>2.20</td>
      <td>0.036</td>
      <td>25.0</td>
      <td>100.0</td>
      <td>0.98938</td>
      <td>3.06</td>
      <td>0.44</td>
      <td>11.8</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4891</th>
      <td>5.7</td>
      <td>0.210</td>
      <td>0.32</td>
      <td>0.90</td>
      <td>0.038</td>
      <td>38.0</td>
      <td>121.0</td>
      <td>0.99074</td>
      <td>3.24</td>
      <td>0.46</td>
      <td>10.6</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4892</th>
      <td>6.5</td>
      <td>0.230</td>
      <td>0.38</td>
      <td>1.30</td>
      <td>0.032</td>
      <td>29.0</td>
      <td>112.0</td>
      <td>0.99298</td>
      <td>3.29</td>
      <td>0.54</td>
      <td>9.7</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4893</th>
      <td>6.2</td>
      <td>0.210</td>
      <td>0.29</td>
      <td>1.60</td>
      <td>0.039</td>
      <td>24.0</td>
      <td>92.0</td>
      <td>0.99114</td>
      <td>3.27</td>
      <td>0.50</td>
      <td>11.2</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4894</th>
      <td>6.6</td>
      <td>0.320</td>
      <td>0.36</td>
      <td>8.00</td>
      <td>0.047</td>
      <td>57.0</td>
      <td>168.0</td>
      <td>0.99490</td>
      <td>3.15</td>
      <td>0.46</td>
      <td>9.6</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4895</th>
      <td>6.5</td>
      <td>0.240</td>
      <td>0.19</td>
      <td>1.20</td>
      <td>0.041</td>
      <td>30.0</td>
      <td>111.0</td>
      <td>0.99254</td>
      <td>2.99</td>
      <td>0.46</td>
      <td>9.4</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4896</th>
      <td>5.5</td>
      <td>0.290</td>
      <td>0.30</td>
      <td>1.10</td>
      <td>0.022</td>
      <td>20.0</td>
      <td>110.0</td>
      <td>0.98869</td>
      <td>3.34</td>
      <td>0.38</td>
      <td>12.8</td>
      <td>7</td>
    </tr>
    <tr>
      <th>4897</th>
      <td>6.0</td>
      <td>0.210</td>
      <td>0.38</td>
      <td>0.80</td>
      <td>0.020</td>
      <td>22.0</td>
      <td>98.0</td>
      <td>0.98941</td>
      <td>3.26</td>
      <td>0.32</td>
      <td>11.8</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>



### Missing data

Based on the result of the `.info()` there is no missing value.


```python
# Shows the resume of the data of Red Wine
red.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1599 entries, 0 to 1598
    Data columns (total 12 columns):
    fixed acidity           1599 non-null float64
    volatile acidity        1599 non-null float64
    citric acid             1599 non-null float64
    residual sugar          1599 non-null float64
    chlorides               1599 non-null float64
    free sulfur dioxide     1599 non-null float64
    total sulfur dioxide    1599 non-null float64
    density                 1599 non-null float64
    pH                      1599 non-null float64
    sulphates               1599 non-null float64
    alcohol                 1599 non-null float64
    quality                 1599 non-null int64
    dtypes: float64(11), int64(1)
    memory usage: 150.0 KB
    


```python
# Shows the resume of the data of White Wine
white.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4898 entries, 0 to 4897
    Data columns (total 12 columns):
    fixed acidity           4898 non-null float64
    volatile acidity        4898 non-null float64
    citric acid             4898 non-null float64
    residual sugar          4898 non-null float64
    chlorides               4898 non-null float64
    free sulfur dioxide     4898 non-null float64
    total sulfur dioxide    4898 non-null float64
    density                 4898 non-null float64
    pH                      4898 non-null float64
    sulphates               4898 non-null float64
    alcohol                 4898 non-null float64
    quality                 4898 non-null int64
    dtypes: float64(11), int64(1)
    memory usage: 459.3 KB
    

### Duplicate

In the red dataset there are 240 duplicated obsevations, and in the white dataset this number is quite big, 937 duplicated.


```python
sum(red.duplicated()),sum(white.duplicated())
```




    (240, 937)



### Unique number

Let's analize the unique number of these two datasets.


```python
red.nunique()
```




    fixed acidity            96
    volatile acidity        143
    citric acid              80
    residual sugar           91
    chlorides               153
    free sulfur dioxide      60
    total sulfur dioxide    144
    density                 436
    pH                       89
    sulphates                96
    alcohol                  65
    quality                   6
    dtype: int64




```python
white.nunique()
```




    fixed acidity            68
    volatile acidity        125
    citric acid              87
    residual sugar          310
    chlorides               160
    free sulfur dioxide     132
    total sulfur dioxide    251
    density                 890
    pH                      103
    sulphates                79
    alcohol                 103
    quality                   7
    dtype: int64



### Mean

Mean of all features of each dataset.


```python
red.mean()
```




    fixed acidity            8.319637
    volatile acidity         0.527821
    citric acid              0.270976
    residual sugar           2.538806
    chlorides                0.087467
    free sulfur dioxide     15.874922
    total sulfur dioxide    46.467792
    density                  0.996747
    pH                       3.311113
    sulphates                0.658149
    alcohol                 10.422983
    quality                  5.636023
    dtype: float64




```python
white.mean()
```




    fixed acidity             6.854788
    volatile acidity          0.278241
    citric acid               0.334192
    residual sugar            6.391415
    chlorides                 0.045772
    free sulfur dioxide      35.308085
    total sulfur dioxide    138.360657
    density                   0.994027
    pH                        3.188267
    sulphates                 0.489847
    alcohol                  10.514267
    quality                   5.877909
    dtype: float64



## Merging

Let's merge these two dataset into one.

### Creating a new variable

I need to create a new variable to be able to distinguish which one is red or white wine. So, I will create the `color` column.


```python
# (1) Creating a column with red labels
color_red = np.repeat("red",red.shape[0])     # red.shape[0] is the number of rows of red dataframe

# (2) Creating a column red white labels
color_white = np.repeat("white",white.shape[0])     # white.shape[0] is the number of rows of white dataframe
```


```python
# Binding the new column (1) with red dataset.
red['color'] = color_red

# Binding the new column (1) with white dataset.
white['color'] = color_white
```

Let's see the first rows and last rows of each data set.


```python
red.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>color</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7.4</td>
      <td>0.70</td>
      <td>0.00</td>
      <td>1.9</td>
      <td>0.076</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>0.9978</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>1</th>
      <td>7.8</td>
      <td>0.88</td>
      <td>0.00</td>
      <td>2.6</td>
      <td>0.098</td>
      <td>25.0</td>
      <td>67.0</td>
      <td>0.9968</td>
      <td>3.20</td>
      <td>0.68</td>
      <td>9.8</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>2</th>
      <td>7.8</td>
      <td>0.76</td>
      <td>0.04</td>
      <td>2.3</td>
      <td>0.092</td>
      <td>15.0</td>
      <td>54.0</td>
      <td>0.9970</td>
      <td>3.26</td>
      <td>0.65</td>
      <td>9.8</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11.2</td>
      <td>0.28</td>
      <td>0.56</td>
      <td>1.9</td>
      <td>0.075</td>
      <td>17.0</td>
      <td>60.0</td>
      <td>0.9980</td>
      <td>3.16</td>
      <td>0.58</td>
      <td>9.8</td>
      <td>6</td>
      <td>red</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.4</td>
      <td>0.70</td>
      <td>0.00</td>
      <td>1.9</td>
      <td>0.076</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>0.9978</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>5</th>
      <td>7.4</td>
      <td>0.66</td>
      <td>0.00</td>
      <td>1.8</td>
      <td>0.075</td>
      <td>13.0</td>
      <td>40.0</td>
      <td>0.9978</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7.9</td>
      <td>0.60</td>
      <td>0.06</td>
      <td>1.6</td>
      <td>0.069</td>
      <td>15.0</td>
      <td>59.0</td>
      <td>0.9964</td>
      <td>3.30</td>
      <td>0.46</td>
      <td>9.4</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7.3</td>
      <td>0.65</td>
      <td>0.00</td>
      <td>1.2</td>
      <td>0.065</td>
      <td>15.0</td>
      <td>21.0</td>
      <td>0.9946</td>
      <td>3.39</td>
      <td>0.47</td>
      <td>10.0</td>
      <td>7</td>
      <td>red</td>
    </tr>
    <tr>
      <th>8</th>
      <td>7.8</td>
      <td>0.58</td>
      <td>0.02</td>
      <td>2.0</td>
      <td>0.073</td>
      <td>9.0</td>
      <td>18.0</td>
      <td>0.9968</td>
      <td>3.36</td>
      <td>0.57</td>
      <td>9.5</td>
      <td>7</td>
      <td>red</td>
    </tr>
    <tr>
      <th>9</th>
      <td>7.5</td>
      <td>0.50</td>
      <td>0.36</td>
      <td>6.1</td>
      <td>0.071</td>
      <td>17.0</td>
      <td>102.0</td>
      <td>0.9978</td>
      <td>3.35</td>
      <td>0.80</td>
      <td>10.5</td>
      <td>5</td>
      <td>red</td>
    </tr>
  </tbody>
</table>
</div>




```python
white.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>color</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7.0</td>
      <td>0.27</td>
      <td>0.36</td>
      <td>20.7</td>
      <td>0.045</td>
      <td>45.0</td>
      <td>170.0</td>
      <td>1.0010</td>
      <td>3.00</td>
      <td>0.45</td>
      <td>8.8</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6.3</td>
      <td>0.30</td>
      <td>0.34</td>
      <td>1.6</td>
      <td>0.049</td>
      <td>14.0</td>
      <td>132.0</td>
      <td>0.9940</td>
      <td>3.30</td>
      <td>0.49</td>
      <td>9.5</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8.1</td>
      <td>0.28</td>
      <td>0.40</td>
      <td>6.9</td>
      <td>0.050</td>
      <td>30.0</td>
      <td>97.0</td>
      <td>0.9951</td>
      <td>3.26</td>
      <td>0.44</td>
      <td>10.1</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7.2</td>
      <td>0.23</td>
      <td>0.32</td>
      <td>8.5</td>
      <td>0.058</td>
      <td>47.0</td>
      <td>186.0</td>
      <td>0.9956</td>
      <td>3.19</td>
      <td>0.40</td>
      <td>9.9</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.2</td>
      <td>0.23</td>
      <td>0.32</td>
      <td>8.5</td>
      <td>0.058</td>
      <td>47.0</td>
      <td>186.0</td>
      <td>0.9956</td>
      <td>3.19</td>
      <td>0.40</td>
      <td>9.9</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>5</th>
      <td>8.1</td>
      <td>0.28</td>
      <td>0.40</td>
      <td>6.9</td>
      <td>0.050</td>
      <td>30.0</td>
      <td>97.0</td>
      <td>0.9951</td>
      <td>3.26</td>
      <td>0.44</td>
      <td>10.1</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6.2</td>
      <td>0.32</td>
      <td>0.16</td>
      <td>7.0</td>
      <td>0.045</td>
      <td>30.0</td>
      <td>136.0</td>
      <td>0.9949</td>
      <td>3.18</td>
      <td>0.47</td>
      <td>9.6</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7.0</td>
      <td>0.27</td>
      <td>0.36</td>
      <td>20.7</td>
      <td>0.045</td>
      <td>45.0</td>
      <td>170.0</td>
      <td>1.0010</td>
      <td>3.00</td>
      <td>0.45</td>
      <td>8.8</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>8</th>
      <td>6.3</td>
      <td>0.30</td>
      <td>0.34</td>
      <td>1.6</td>
      <td>0.049</td>
      <td>14.0</td>
      <td>132.0</td>
      <td>0.9940</td>
      <td>3.30</td>
      <td>0.49</td>
      <td>9.5</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>9</th>
      <td>8.1</td>
      <td>0.22</td>
      <td>0.43</td>
      <td>1.5</td>
      <td>0.044</td>
      <td>28.0</td>
      <td>129.0</td>
      <td>0.9938</td>
      <td>3.22</td>
      <td>0.45</td>
      <td>11.0</td>
      <td>6</td>
      <td>white</td>
    </tr>
  </tbody>
</table>
</div>




```python
red.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>color</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1589</th>
      <td>6.6</td>
      <td>0.725</td>
      <td>0.20</td>
      <td>7.8</td>
      <td>0.073</td>
      <td>29.0</td>
      <td>79.0</td>
      <td>0.99770</td>
      <td>3.29</td>
      <td>0.54</td>
      <td>9.2</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>1590</th>
      <td>6.3</td>
      <td>0.550</td>
      <td>0.15</td>
      <td>1.8</td>
      <td>0.077</td>
      <td>26.0</td>
      <td>35.0</td>
      <td>0.99314</td>
      <td>3.32</td>
      <td>0.82</td>
      <td>11.6</td>
      <td>6</td>
      <td>red</td>
    </tr>
    <tr>
      <th>1591</th>
      <td>5.4</td>
      <td>0.740</td>
      <td>0.09</td>
      <td>1.7</td>
      <td>0.089</td>
      <td>16.0</td>
      <td>26.0</td>
      <td>0.99402</td>
      <td>3.67</td>
      <td>0.56</td>
      <td>11.6</td>
      <td>6</td>
      <td>red</td>
    </tr>
    <tr>
      <th>1592</th>
      <td>6.3</td>
      <td>0.510</td>
      <td>0.13</td>
      <td>2.3</td>
      <td>0.076</td>
      <td>29.0</td>
      <td>40.0</td>
      <td>0.99574</td>
      <td>3.42</td>
      <td>0.75</td>
      <td>11.0</td>
      <td>6</td>
      <td>red</td>
    </tr>
    <tr>
      <th>1593</th>
      <td>6.8</td>
      <td>0.620</td>
      <td>0.08</td>
      <td>1.9</td>
      <td>0.068</td>
      <td>28.0</td>
      <td>38.0</td>
      <td>0.99651</td>
      <td>3.42</td>
      <td>0.82</td>
      <td>9.5</td>
      <td>6</td>
      <td>red</td>
    </tr>
    <tr>
      <th>1594</th>
      <td>6.2</td>
      <td>0.600</td>
      <td>0.08</td>
      <td>2.0</td>
      <td>0.090</td>
      <td>32.0</td>
      <td>44.0</td>
      <td>0.99490</td>
      <td>3.45</td>
      <td>0.58</td>
      <td>10.5</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>1595</th>
      <td>5.9</td>
      <td>0.550</td>
      <td>0.10</td>
      <td>2.2</td>
      <td>0.062</td>
      <td>39.0</td>
      <td>51.0</td>
      <td>0.99512</td>
      <td>3.52</td>
      <td>0.76</td>
      <td>11.2</td>
      <td>6</td>
      <td>red</td>
    </tr>
    <tr>
      <th>1596</th>
      <td>6.3</td>
      <td>0.510</td>
      <td>0.13</td>
      <td>2.3</td>
      <td>0.076</td>
      <td>29.0</td>
      <td>40.0</td>
      <td>0.99574</td>
      <td>3.42</td>
      <td>0.75</td>
      <td>11.0</td>
      <td>6</td>
      <td>red</td>
    </tr>
    <tr>
      <th>1597</th>
      <td>5.9</td>
      <td>0.645</td>
      <td>0.12</td>
      <td>2.0</td>
      <td>0.075</td>
      <td>32.0</td>
      <td>44.0</td>
      <td>0.99547</td>
      <td>3.57</td>
      <td>0.71</td>
      <td>10.2</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>1598</th>
      <td>6.0</td>
      <td>0.310</td>
      <td>0.47</td>
      <td>3.6</td>
      <td>0.067</td>
      <td>18.0</td>
      <td>42.0</td>
      <td>0.99549</td>
      <td>3.39</td>
      <td>0.66</td>
      <td>11.0</td>
      <td>6</td>
      <td>red</td>
    </tr>
  </tbody>
</table>
</div>




```python
white.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>color</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4888</th>
      <td>6.8</td>
      <td>0.220</td>
      <td>0.36</td>
      <td>1.20</td>
      <td>0.052</td>
      <td>38.0</td>
      <td>127.0</td>
      <td>0.99330</td>
      <td>3.04</td>
      <td>0.54</td>
      <td>9.2</td>
      <td>5</td>
      <td>white</td>
    </tr>
    <tr>
      <th>4889</th>
      <td>4.9</td>
      <td>0.235</td>
      <td>0.27</td>
      <td>11.75</td>
      <td>0.030</td>
      <td>34.0</td>
      <td>118.0</td>
      <td>0.99540</td>
      <td>3.07</td>
      <td>0.50</td>
      <td>9.4</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>4890</th>
      <td>6.1</td>
      <td>0.340</td>
      <td>0.29</td>
      <td>2.20</td>
      <td>0.036</td>
      <td>25.0</td>
      <td>100.0</td>
      <td>0.98938</td>
      <td>3.06</td>
      <td>0.44</td>
      <td>11.8</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>4891</th>
      <td>5.7</td>
      <td>0.210</td>
      <td>0.32</td>
      <td>0.90</td>
      <td>0.038</td>
      <td>38.0</td>
      <td>121.0</td>
      <td>0.99074</td>
      <td>3.24</td>
      <td>0.46</td>
      <td>10.6</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>4892</th>
      <td>6.5</td>
      <td>0.230</td>
      <td>0.38</td>
      <td>1.30</td>
      <td>0.032</td>
      <td>29.0</td>
      <td>112.0</td>
      <td>0.99298</td>
      <td>3.29</td>
      <td>0.54</td>
      <td>9.7</td>
      <td>5</td>
      <td>white</td>
    </tr>
    <tr>
      <th>4893</th>
      <td>6.2</td>
      <td>0.210</td>
      <td>0.29</td>
      <td>1.60</td>
      <td>0.039</td>
      <td>24.0</td>
      <td>92.0</td>
      <td>0.99114</td>
      <td>3.27</td>
      <td>0.50</td>
      <td>11.2</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>4894</th>
      <td>6.6</td>
      <td>0.320</td>
      <td>0.36</td>
      <td>8.00</td>
      <td>0.047</td>
      <td>57.0</td>
      <td>168.0</td>
      <td>0.99490</td>
      <td>3.15</td>
      <td>0.46</td>
      <td>9.6</td>
      <td>5</td>
      <td>white</td>
    </tr>
    <tr>
      <th>4895</th>
      <td>6.5</td>
      <td>0.240</td>
      <td>0.19</td>
      <td>1.20</td>
      <td>0.041</td>
      <td>30.0</td>
      <td>111.0</td>
      <td>0.99254</td>
      <td>2.99</td>
      <td>0.46</td>
      <td>9.4</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>4896</th>
      <td>5.5</td>
      <td>0.290</td>
      <td>0.30</td>
      <td>1.10</td>
      <td>0.022</td>
      <td>20.0</td>
      <td>110.0</td>
      <td>0.98869</td>
      <td>3.34</td>
      <td>0.38</td>
      <td>12.8</td>
      <td>7</td>
      <td>white</td>
    </tr>
    <tr>
      <th>4897</th>
      <td>6.0</td>
      <td>0.210</td>
      <td>0.38</td>
      <td>0.80</td>
      <td>0.020</td>
      <td>22.0</td>
      <td>98.0</td>
      <td>0.98941</td>
      <td>3.26</td>
      <td>0.32</td>
      <td>11.8</td>
      <td>6</td>
      <td>white</td>
    </tr>
  </tbody>
</table>
</div>



### Combining

The red and white dataset could be binded using the `.append()` method from numpy.


```python
# Binding red and white datasets.
wine = red.append(white)

# Head
wine.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>color</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7.4</td>
      <td>0.700</td>
      <td>0.00</td>
      <td>1.9</td>
      <td>0.076</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>0.9978</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>1</th>
      <td>7.8</td>
      <td>0.880</td>
      <td>0.00</td>
      <td>2.6</td>
      <td>0.098</td>
      <td>25.0</td>
      <td>67.0</td>
      <td>0.9968</td>
      <td>3.20</td>
      <td>0.68</td>
      <td>9.8</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>2</th>
      <td>7.8</td>
      <td>0.760</td>
      <td>0.04</td>
      <td>2.3</td>
      <td>0.092</td>
      <td>15.0</td>
      <td>54.0</td>
      <td>0.9970</td>
      <td>3.26</td>
      <td>0.65</td>
      <td>9.8</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11.2</td>
      <td>0.280</td>
      <td>0.56</td>
      <td>1.9</td>
      <td>0.075</td>
      <td>17.0</td>
      <td>60.0</td>
      <td>0.9980</td>
      <td>3.16</td>
      <td>0.58</td>
      <td>9.8</td>
      <td>6</td>
      <td>red</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.4</td>
      <td>0.700</td>
      <td>0.00</td>
      <td>1.9</td>
      <td>0.076</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>0.9978</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>5</th>
      <td>7.4</td>
      <td>0.660</td>
      <td>0.00</td>
      <td>1.8</td>
      <td>0.075</td>
      <td>13.0</td>
      <td>40.0</td>
      <td>0.9978</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7.9</td>
      <td>0.600</td>
      <td>0.06</td>
      <td>1.6</td>
      <td>0.069</td>
      <td>15.0</td>
      <td>59.0</td>
      <td>0.9964</td>
      <td>3.30</td>
      <td>0.46</td>
      <td>9.4</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7.3</td>
      <td>0.650</td>
      <td>0.00</td>
      <td>1.2</td>
      <td>0.065</td>
      <td>15.0</td>
      <td>21.0</td>
      <td>0.9946</td>
      <td>3.39</td>
      <td>0.47</td>
      <td>10.0</td>
      <td>7</td>
      <td>red</td>
    </tr>
    <tr>
      <th>8</th>
      <td>7.8</td>
      <td>0.580</td>
      <td>0.02</td>
      <td>2.0</td>
      <td>0.073</td>
      <td>9.0</td>
      <td>18.0</td>
      <td>0.9968</td>
      <td>3.36</td>
      <td>0.57</td>
      <td>9.5</td>
      <td>7</td>
      <td>red</td>
    </tr>
    <tr>
      <th>9</th>
      <td>7.5</td>
      <td>0.500</td>
      <td>0.36</td>
      <td>6.1</td>
      <td>0.071</td>
      <td>17.0</td>
      <td>102.0</td>
      <td>0.9978</td>
      <td>3.35</td>
      <td>0.80</td>
      <td>10.5</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>10</th>
      <td>6.7</td>
      <td>0.580</td>
      <td>0.08</td>
      <td>1.8</td>
      <td>0.097</td>
      <td>15.0</td>
      <td>65.0</td>
      <td>0.9959</td>
      <td>3.28</td>
      <td>0.54</td>
      <td>9.2</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>11</th>
      <td>7.5</td>
      <td>0.500</td>
      <td>0.36</td>
      <td>6.1</td>
      <td>0.071</td>
      <td>17.0</td>
      <td>102.0</td>
      <td>0.9978</td>
      <td>3.35</td>
      <td>0.80</td>
      <td>10.5</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>12</th>
      <td>5.6</td>
      <td>0.615</td>
      <td>0.00</td>
      <td>1.6</td>
      <td>0.089</td>
      <td>16.0</td>
      <td>59.0</td>
      <td>0.9943</td>
      <td>3.58</td>
      <td>0.52</td>
      <td>9.9</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>13</th>
      <td>7.8</td>
      <td>0.610</td>
      <td>0.29</td>
      <td>1.6</td>
      <td>0.114</td>
      <td>9.0</td>
      <td>29.0</td>
      <td>0.9974</td>
      <td>3.26</td>
      <td>1.56</td>
      <td>9.1</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>14</th>
      <td>8.9</td>
      <td>0.620</td>
      <td>0.18</td>
      <td>3.8</td>
      <td>0.176</td>
      <td>52.0</td>
      <td>145.0</td>
      <td>0.9986</td>
      <td>3.16</td>
      <td>0.88</td>
      <td>9.2</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>15</th>
      <td>8.9</td>
      <td>0.620</td>
      <td>0.19</td>
      <td>3.9</td>
      <td>0.170</td>
      <td>51.0</td>
      <td>148.0</td>
      <td>0.9986</td>
      <td>3.17</td>
      <td>0.93</td>
      <td>9.2</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>16</th>
      <td>8.5</td>
      <td>0.280</td>
      <td>0.56</td>
      <td>1.8</td>
      <td>0.092</td>
      <td>35.0</td>
      <td>103.0</td>
      <td>0.9969</td>
      <td>3.30</td>
      <td>0.75</td>
      <td>10.5</td>
      <td>7</td>
      <td>red</td>
    </tr>
    <tr>
      <th>17</th>
      <td>8.1</td>
      <td>0.560</td>
      <td>0.28</td>
      <td>1.7</td>
      <td>0.368</td>
      <td>16.0</td>
      <td>56.0</td>
      <td>0.9968</td>
      <td>3.11</td>
      <td>1.28</td>
      <td>9.3</td>
      <td>5</td>
      <td>red</td>
    </tr>
    <tr>
      <th>18</th>
      <td>7.4</td>
      <td>0.590</td>
      <td>0.08</td>
      <td>4.4</td>
      <td>0.086</td>
      <td>6.0</td>
      <td>29.0</td>
      <td>0.9974</td>
      <td>3.38</td>
      <td>0.50</td>
      <td>9.0</td>
      <td>4</td>
      <td>red</td>
    </tr>
    <tr>
      <th>19</th>
      <td>7.9</td>
      <td>0.320</td>
      <td>0.51</td>
      <td>1.8</td>
      <td>0.341</td>
      <td>17.0</td>
      <td>56.0</td>
      <td>0.9969</td>
      <td>3.04</td>
      <td>1.08</td>
      <td>9.2</td>
      <td>6</td>
      <td>red</td>
    </tr>
  </tbody>
</table>
</div>




```python
wine.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 6497 entries, 0 to 4897
    Data columns (total 13 columns):
    fixed acidity           6497 non-null float64
    volatile acidity        6497 non-null float64
    citric acid             6497 non-null float64
    residual sugar          6497 non-null float64
    chlorides               6497 non-null float64
    free sulfur dioxide     6497 non-null float64
    total sulfur dioxide    6497 non-null float64
    density                 6497 non-null float64
    pH                      6497 non-null float64
    sulphates               6497 non-null float64
    alcohol                 6497 non-null float64
    quality                 6497 non-null int64
    color                   6497 non-null object
    dtypes: float64(11), int64(1), object(1)
    memory usage: 710.6+ KB
    


```python
red.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1599 entries, 0 to 1598
    Data columns (total 13 columns):
    fixed acidity           1599 non-null float64
    volatile acidity        1599 non-null float64
    citric acid             1599 non-null float64
    residual sugar          1599 non-null float64
    chlorides               1599 non-null float64
    free sulfur dioxide     1599 non-null float64
    total sulfur dioxide    1599 non-null float64
    density                 1599 non-null float64
    pH                      1599 non-null float64
    sulphates               1599 non-null float64
    alcohol                 1599 non-null float64
    quality                 1599 non-null int64
    color                   1599 non-null object
    dtypes: float64(11), int64(1), object(1)
    memory usage: 162.5+ KB
    


```python
white.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4898 entries, 0 to 4897
    Data columns (total 13 columns):
    fixed acidity           4898 non-null float64
    volatile acidity        4898 non-null float64
    citric acid             4898 non-null float64
    residual sugar          4898 non-null float64
    chlorides               4898 non-null float64
    free sulfur dioxide     4898 non-null float64
    total sulfur dioxide    4898 non-null float64
    density                 4898 non-null float64
    pH                      4898 non-null float64
    sulphates               4898 non-null float64
    alcohol                 4898 non-null float64
    quality                 4898 non-null int64
    color                   4898 non-null object
    dtypes: float64(11), int64(1), object(1)
    memory usage: 497.5+ KB
    


```python
# save this for later
wine.to_csv('winequality_edited.csv', index=False)
```

### Troubleshooting

Sometimes the columns names are quite different, so we need to modify/edit those them before `.append()` the data frames.

The method used to get the columns name is `.columns`.

Like this:


```python
red.columns # Print the red columns names.
```




    Index(['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar',
           'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density',
           'pH', 'sulphates', 'alcohol', 'quality', 'color'],
          dtype='object')



You could save this column into a new variable to use to assign in other data frame.

```
# Saving the columns names
columns_name = red.columns # Using the .columns method

data_frame_x.columns = columns_name # Assigning new columns names
```
Keep in mind that you could change only one name, to do it you need to coerce the columns name to a list.

```
columns_name = list(red.columns) # Coerce to a list
columns_name[6] = "nem name"     # fix the name
red.columns = columns_name       # assign to fix all the columns.
```

## Exploratory Data Analysis (EDA)

Here I will perform a very simple and straightforward EDA. Let's strat with histograms.

* Fixed Acidity;
* Total Sulfur Dioxide;
* pH, and;
* Alcohol.


```python
# Big picture: Scatter plot + histogram
pd.plotting.scatter_matrix(wine,figsize=(15,15))
```




    array([[<matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1CDB37F0>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D068470>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D092A90>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D0C4160>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D0E86D8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D0E8710>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D143438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D169AC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D19B198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D1C2828>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D1ECEB8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D21A588>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D242C18>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D2742E8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D29C978>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D2CD048>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D2F46D8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D31CD68>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D34B438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D375AC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D3A5198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D3CC828>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D3F4EB8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D426588>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D44DC18>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D4802E8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D4A7978>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D4D8048>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D4FF6D8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D527D68>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D559438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D57FAC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D5B3198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D5D9828>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D602EB8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D630588>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D659C18>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D68B2E8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D6AF978>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D6E5048>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D70C6D8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D732D68>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D764438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D78DAC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D7BF198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D7E3828>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D80EEB8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D83F588>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D865C18>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D8982E8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D8C0978>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D8ED048>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D9176D8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D93FD68>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D96F438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D996AC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D9C8198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1D9EE828>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DA18EB8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DA4B588>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DA72C18>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DAA32E8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DAC9978>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DAFB048>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DB226D8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DB4DD68>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DB7C438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DBA3AC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DBD4198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DBFB828>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DC21EB8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DC55588>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DC7CC18>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DCAE2E8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DCD4978>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DD07048>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DD2E6D8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DD55D68>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DD87438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DDADAC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DDDF198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DE07828>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DE30EB8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DE5F588>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DE85C18>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DEBA2E8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DEDF978>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DF11048>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DF3A6D8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DF63D68>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DF92438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DFBAAC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1DFEB198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E013828>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E03AEB8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E06C588>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E093C18>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E0C62E8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E0EC978>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E11F048>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E1456D8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E16DD68>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E19D438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E1C4AC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E1F7198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E21E828>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E247EB8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E277588>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E29EC18>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E2D02E8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E2F6978>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E32B048>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E3536D8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E379D68>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E3A9438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E3D1AC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E402198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E429828>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E453EB8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E483588>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E4AAC18>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E4DD2E8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E503978>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E537048>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E55C6D8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E586D68>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E5B6438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E5DEAC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E60D198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E638828>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E65FEB8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E68F588>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E6B7C18>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E6E72E8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E70C978>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E741048>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E7696D8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E790D68>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E7C2438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E7E8AC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E81A198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E841828>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E86BEB8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000024A1E89C588>]],
          dtype=object)




![png](output_41_1.png)



```python
wine['fixed acidity'].plot(kind ='hist', figsize = (12,4));
```


![png](output_42_0.png)


The above histogram seems a bit skewed to right.


```python
wine['total sulfur dioxide'].plot(kind ='hist', figsize = (12,4));
```


![png](output_44_0.png)



```python
wine['pH'].plot(kind ='hist', figsize = (12,4));
```


![png](output_45_0.png)



```python
wine['alcohol'].plot(kind ='hist', figsize = (12,4));
```


![png](output_46_0.png)


The above histogram seems a bit skewed to right.

### Scatterplots of Quality Against Various Features


```python
wine.plot(x = "volatile acidity", y = "quality" , kind = "scatter", figsize = (12,4))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x24a21104cf8>




![png](output_49_1.png)



```python
wine.plot(x = "residual sugar", y = "quality" , kind = "scatter", figsize = (12,4))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x24a21153f60>




![png](output_50_1.png)



```python
wine.plot(x = "alcohol", y = "quality" , kind = "scatter", figsize = (12,4))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x24a211b74e0>




![png](output_51_1.png)



```python
wine.plot(x = "pH", y = "quality" , kind = "scatter", figsize = (12,4))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x24a2121d8d0>




![png](output_52_1.png)


### Group_by

Using the `Group_by` method could help a lot if you are going to analize the data from differents perspectivies. A regular `.mean()` usually is not a good idea because you can not divided into categories. Using the `Group_by` this is easy to use and very handy.


```python
# Example of mean() by quality.
wine.groupby('quality').mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
    </tr>
    <tr>
      <th>quality</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>7.853333</td>
      <td>0.517000</td>
      <td>0.281000</td>
      <td>5.140000</td>
      <td>0.077033</td>
      <td>39.216667</td>
      <td>122.033333</td>
      <td>0.995744</td>
      <td>3.257667</td>
      <td>0.506333</td>
      <td>10.215000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.288889</td>
      <td>0.457963</td>
      <td>0.272315</td>
      <td>4.153704</td>
      <td>0.060056</td>
      <td>20.636574</td>
      <td>103.432870</td>
      <td>0.994833</td>
      <td>3.231620</td>
      <td>0.505648</td>
      <td>10.180093</td>
    </tr>
    <tr>
      <th>5</th>
      <td>7.326801</td>
      <td>0.389614</td>
      <td>0.307722</td>
      <td>5.804116</td>
      <td>0.064666</td>
      <td>30.237371</td>
      <td>120.839102</td>
      <td>0.995849</td>
      <td>3.212189</td>
      <td>0.526403</td>
      <td>9.837783</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7.177257</td>
      <td>0.313863</td>
      <td>0.323583</td>
      <td>5.549753</td>
      <td>0.054157</td>
      <td>31.165021</td>
      <td>115.410790</td>
      <td>0.994558</td>
      <td>3.217726</td>
      <td>0.532549</td>
      <td>10.587553</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7.128962</td>
      <td>0.288800</td>
      <td>0.334764</td>
      <td>4.731696</td>
      <td>0.045272</td>
      <td>30.422150</td>
      <td>108.498610</td>
      <td>0.993126</td>
      <td>3.228072</td>
      <td>0.547025</td>
      <td>11.386006</td>
    </tr>
    <tr>
      <th>8</th>
      <td>6.835233</td>
      <td>0.291010</td>
      <td>0.332539</td>
      <td>5.382902</td>
      <td>0.041124</td>
      <td>34.533679</td>
      <td>117.518135</td>
      <td>0.992514</td>
      <td>3.223212</td>
      <td>0.512487</td>
      <td>11.678756</td>
    </tr>
    <tr>
      <th>9</th>
      <td>7.420000</td>
      <td>0.298000</td>
      <td>0.386000</td>
      <td>4.120000</td>
      <td>0.027400</td>
      <td>33.400000</td>
      <td>116.000000</td>
      <td>0.991460</td>
      <td>3.308000</td>
      <td>0.466000</td>
      <td>12.180000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# In this case there are two parameters inside of the Group.
# Must use a list to perform this way
wine.groupby(['quality','alcohol']).mean().head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
    </tr>
    <tr>
      <th>quality</th>
      <th>alcohol</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">3</th>
      <th>8.0</th>
      <td>4.2</td>
      <td>0.215</td>
      <td>0.23</td>
      <td>5.1</td>
      <td>0.0410</td>
      <td>64.0</td>
      <td>157.0</td>
      <td>0.99688</td>
      <td>3.420</td>
      <td>0.44</td>
    </tr>
    <tr>
      <th>8.4</th>
      <td>10.4</td>
      <td>0.610</td>
      <td>0.49</td>
      <td>2.1</td>
      <td>0.2000</td>
      <td>5.0</td>
      <td>16.0</td>
      <td>0.99940</td>
      <td>3.160</td>
      <td>0.63</td>
    </tr>
    <tr>
      <th>8.5</th>
      <td>9.1</td>
      <td>0.590</td>
      <td>0.38</td>
      <td>1.6</td>
      <td>0.0660</td>
      <td>34.0</td>
      <td>182.0</td>
      <td>0.99680</td>
      <td>3.230</td>
      <td>0.38</td>
    </tr>
    <tr>
      <th>9.0</th>
      <td>11.6</td>
      <td>0.580</td>
      <td>0.66</td>
      <td>2.2</td>
      <td>0.0740</td>
      <td>10.0</td>
      <td>47.0</td>
      <td>1.00080</td>
      <td>3.250</td>
      <td>0.57</td>
    </tr>
    <tr>
      <th>9.1</th>
      <td>7.7</td>
      <td>0.480</td>
      <td>0.35</td>
      <td>7.6</td>
      <td>0.1485</td>
      <td>20.5</td>
      <td>180.5</td>
      <td>0.99705</td>
      <td>3.005</td>
      <td>0.62</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Refining the above analysis adding the 'pH' as a filter.
wine.groupby(['quality','alcohol'])['pH'].mean().head() # .head() because is long this table
```




    quality  alcohol
    3        8.0        3.420
             8.4        3.160
             8.5        3.230
             9.0        3.250
             9.1        3.005
    Name: pH, dtype: float64



Extracted from the 13.Concluions Using Groupby (Lesson 02 from Part 2)

## Drawing Conclusions Using `groupby`

This section I will pratice a bit using the `.groupby()` method to aid me in some subsetting, this method allow me to create some analysis such as:

* Summarize a variable calculating the `.mean()`, `.max()`, `.min()` etc;
* Create new `category`, in this case the `acidity_levels` to make a new classification.

### Q1: Is a certain type of wine (red or white) associated with higher quality?

For this question, compare the average quality of red wine with the average quality of white wine with groupby. To do this group by color and then find the mean quality of each group.

**Answer:** Using the `.groupby()` I need to define what is going to be grouped, in this case `color`, later I just want one features to be showed. So, I filter by `quality`, and then calculated the `.mean()`.


```python
# Find the mean quality of each wine type (red and white) with groupby
wine.groupby('color')['quality'].mean()
```




    color
    red      5.636023
    white    5.877909
    Name: quality, dtype: float64



### Q2: What level of acidity (pH value) receives the highest average rating?
This question is more tricky because unlike color, which has clear categories you can group by (red and white) pH is a quantitative variable without clear categories. However, there is a simple fix to this. You can create a categorical variable from a quantitative variable by creating your own categories. pandas' cut function let's you "cut" data in groups. Using this, create a new column called acidity_levels with these categories:

#### Acidity Levels:

1. High: Lowest 25% of pH values
2. Moderately High: 25% - 50% of pH values
3. Medium: 50% - 75% of pH values
4. Low: 75% - max pH value

Here, the data is being split at the 25th, 50th, and 75th percentile. Remember, you can get these numbers with pandas' describe()! After you create these four categories, you'll be able to use groupby to get the mean quality rating for each acidity level.


```python
# View the min, 25%, 50%, 75%, max pH values with Pandas describe
wine['pH'].describe()
```




    count    6497.000000
    mean        3.218501
    std         0.160787
    min         2.720000
    25%         3.110000
    50%         3.210000
    75%         3.320000
    max         4.010000
    Name: pH, dtype: float64



Let's define some _cuts_ for each level of acidity, this "levels" will be the content of a new column. This _cuts_ will be use the results of the `pH` features from `.describe()`.


```python
# Bin edges that will be used to "cut" the data into groups
bin_edges = [2.72,3.11,3.21,3.32,4.01] # Fill in this list with five values you just found
```

Now, let's define the categories based on the `.describe()`.

* 2.72 - 3.11: high
* 3.11 - 3.21: mod_high
* 3.21 - 3.32: medium
* 3.21 - 4.01: low


```python
# Labels for the four acidity level groups
bin_names = ['high', 'mod_high', 'medium', 'low'] # Name each acidity level category
```

After define the `bin_edges` and `bin_names` I can used it to create a new column called `acidity_levels` with a classification of `pH` (could be 'high', 'mod_high', 'medium', or 'low').


```python
# Creates acidity_levels column
wine['acidity_levels'] = pd.cut(wine['pH'], bin_edges, labels=bin_names)

# Checks for successful creation of this column
wine[['acidity_levels','pH','quality']].head(10) # First 9 rows filtered by pH and acidity_levels
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>acidity_levels</th>
      <th>pH</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>low</td>
      <td>3.51</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mod_high</td>
      <td>3.20</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>medium</td>
      <td>3.26</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>mod_high</td>
      <td>3.16</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>low</td>
      <td>3.51</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>low</td>
      <td>3.51</td>
      <td>5</td>
    </tr>
    <tr>
      <th>6</th>
      <td>medium</td>
      <td>3.30</td>
      <td>5</td>
    </tr>
    <tr>
      <th>7</th>
      <td>low</td>
      <td>3.39</td>
      <td>7</td>
    </tr>
    <tr>
      <th>8</th>
      <td>low</td>
      <td>3.36</td>
      <td>7</td>
    </tr>
    <tr>
      <th>9</th>
      <td>low</td>
      <td>3.35</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>



Finally, I can calculated the `.mean()` of the `quality` for each `acidity_levels`.


```python
# Find the mean quality of each acidity level with groupby
wine.groupby(['acidity_levels']).mean().quality
```




    acidity_levels
    high        5.783343
    mod_high    5.784540
    medium      5.850832
    low         5.859593
    Name: quality, dtype: float64



## Drawing Conclusions Using `Query`

The same way I have made to `.groupby()`, I will have some pratice using the `Query`, and to do so I will answer some generic questions.

**ATENTION:** To use the `query` the columns must be edited to remove any space. For this reason, It is a good idea to use the `.rename()` method to substitute the spaces to underscores.

### Q1 Do wines with higher alcoholic content receive better ratings?

To answer this question I need to calculate the `.mean()` and later split the dataset into two and compare.


```python
# get the median amount of alcohol content
wine_mean = wine['alcohol'].median()

print(wine_mean) # Print the mean.
```

    10.3
    

I will split the dataset using the `wine_mean` as a filter, and I may use the `Query` to do it.

* low_alcohol: Wine dataset subset with observations bellow to the  mean;
* high_alcohol: Wine dataset subset with observations above or equal to the mean.


```python
# select samples with alcohol content less than the median
# low_alcohol = wine[wine['alcohol'] < wine_mean]
low_alcohol = wine.query('alcohol < 10.3') # Using the Query, but I must write the mean as number,
                                           # I can not reference a variable.

# select samples with alcohol content greater than or equal to the median
# high_alcohol = wine[wine['alcohol'] >= wine_mean]
high_alcohol = wine.query('alcohol >= 10.3') # Using the Query
```

Proving the summation of the columns from each dataset are equal to the orginal one.


```python
# ensure these queries included each sample exactly once
num_samples = wine.shape[0]
num_samples == low_alcohol['quality'].count() + high_alcohol['quality'].count() # should be True
```




    True



Now, let's calculate the average of the quality from these splited dataset.


```python
print("Much alcohol recieve a better qualification??\n")
# get mean quality rating for the low alcohol and high alcohol groups
low,high = [low_alcohol.mean().quality,high_alcohol.mean().quality]

print("Low: {}, High: {}".format(low,high))
```

    Much alcohol recieve a better qualification??
    
    Low: 5.475920679886686, High: 6.146084337349397
    

Based on the higher average of high_alcohol wines, the higher percentage of alcohol could led a better qualification.

### Do sweeter wines receive better ratings?

This study could be performed analysing the residual sugar, so let's apply the `.median()` to calculate the average.


```python
# get the median amount of residual sugar
res_sugar_median = wine['residual sugar'].median()

# Print
print(res_sugar_median)
```

    3.0
    

Analogy to the Q1, I will split the wine dataset into two separated datasets, based on the mean of the residual sugar. First, I will modify the columns names.


```python
# The rename methods deals with changin spaces to underscores and lower casing everything.
wine.rename(columns=lambda x: x.strip().lower().replace(" ", "_"), inplace = True)
```

Keep in mind to change any space to underscores.

Now, let's split the dataset in two parts.


```python
# select samples with residual sugar less than the median
low_sugar = wine.query('residual_sugar < {}'.format(res_sugar_median)) # Only possible if I change spaces to underscore.
#low_sugar = wine[wine['residual sugar'] < res_sugar_mean]             # Same results

# select samples with residual sugar greater than or equal to the median
high_sugar = wine.query('residual_sugar >= {}'.format(res_sugar_median))
#high_sugar = wine[wine['residual sugar'] >= res_sugar_mean]
```


```python
# ensure these queries included each sample exactly once
num_samples == low_sugar['quality'].count() + high_sugar['quality'].count() # should be True
```




    True




```python
print("Sweeter recieve a slight better qualification??\n")
# get mean quality rating for the low sugar and high sugar groups
low, high = [low_sugar.mean().quality,high_sugar.mean().quality]
print("Low: {}, High:{} ".format(low,high))
```

    Sweeter recieve a slight better qualification??
    
    Low: 5.808800743724822, High:5.82782874617737 
    

Based on the above results, a swetter wine has a better ratings.

## Plotting Wine Color and Quality

In this exercise I will use the `groupby` method to plot some graphics.

Let's start subsetting the dataframe.


```python
# Let's print some info and later I will plot a graphic
wine.groupby('color')['quality'].mean()
```




    color
    red      5.636023
    white    5.877909
    Name: quality, dtype: float64



So, I summarized the mean of quality for the two kinds of wine. Now, I would like a good visualization of this in a bar chart.


```python
# Same info but now in a plot code.
wine.groupby('color')['quality'].mean().plot(kind='bar')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x24a22fabb70>




![png](output_90_1.png)


This graphic is basic, but I could add some features to let it more aesthetic.


```python
# Same code but with a lot of more features.
wine.groupby('color')['quality'].mean().plot(kind='bar',
                                             title = 'Average Wine Quality by Color',
                                             color = ['red','blue'],
                                             alpha = 0.7)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x24a211aa668>




![png](output_92_1.png)


Let's import some libraries to enhance the experience with plots.

* seaborn: Directly I do not use any method, but I used indirectly (I do not know yet);
* pyplot: Allow me to edit the axis, title and some other features.


```python
import matplotlib.pyplot as plt
import seaborn as sns
% matplotlib inline
```

Again, subsetting my dataframe, plotting using the `.plot` method, and later editing the x and y labels using the `pyplot`.


```python
# Same code but I splited to be confortable to read.
wine_type = wine.groupby('color')['quality'].mean()

# Now much better
wine_type.plot(kind='bar',title = 'Average Wine Quality by Color',color = ['red','blue'],alpha = 0.7)

plt.xlabel('Colors', fontsize = 18)  # Add the X labels
plt.ylabel('Quality', fontsize = 18) # Add the Y labels
```




    Text(0,0.5,'Quality')




![png](output_96_1.png)


What about a more complex graphic?

Let's use two variables, so subsetting using `groupby`, defining the list of variable to be filtered (in this case ['quality','color']), and counting by `ph`


```python
# Let's make an other subsetting to plot an interesting example
# Keep in mind that the pH column has change the name to ph.
counts = wine.groupby(['quality','color']).count()['ph']

# Print
counts
```




    quality  color
    3        red        10
             white      20
    4        red        53
             white     163
    5        red       681
             white    1457
    6        red       638
             white    2198
    7        red       199
             white     880
    8        red        18
             white     175
    9        white       5
    Name: ph, dtype: int64



Plotting the counts variable in a graphic.


```python
counts.plot(kind='bar', title='Counts by Wine Color and Colors', color = ['red','blue'],alpha=0.7)

plt.xlabel('Quality and Colors',fontsize=18)
plt.ylabel('Count',fontsize=18)
```




    Text(0,0.5,'Count')




![png](output_100_1.png)


To make a fair comparison I need to put all these two categories in the same level, so let's divide the counts by the total.


```python
totals = wine.groupby('color').count()['ph']

proportions = counts / totals

proportions.plot(kind='bar', title='Counts by Wine Color and Colors', color = ['red','blue'],alpha=0.7)

plt.xlabel('Quality and Colors',fontsize=18)
plt.ylabel('Count',fontsize=18)
```




    Text(0,0.5,'Count')




![png](output_102_1.png)


## Creating a Bar Chart Using Matplotlib

These next examples were extracted from the class 18. Case Study 01, is a progressive way to adding some features.

### Simple bar plot, declaring the values by position.


```python
plt.bar([1, 2, 3], [224, 620, 425]);
```


![png](output_104_0.png)



```python
# Same plot but declaring the variables by names.
plt.bar(x = [1, 2, 3], height = [224, 620, 425]);
```


![png](output_105_0.png)


### Markers

Remove the x label markers, the line codes commands must be in sequence.


```python
# plot bars
plt.bar([1, 2, 3], [224, 620, 425])

# specify x coordinates of tick labels and their labels
plt.xticks([1, 2, 3], ['a', 'b', 'c']);
```


![png](output_107_0.png)


### Rename the labels

Rename the x axis lables.


```python
# plot bars with x tick labels
plt.bar([1, 2, 3], [224, 620, 425], tick_label=['high', 'mid', 'low']);
```


![png](output_109_0.png)


### Add title.


```python
plt.bar([1, 2, 3], [224, 620, 425], tick_label=['a', 'b', 'c'])
plt.title('Some Title')
plt.xlabel('Some X Label')
plt.ylabel('Some Y Label');
```


![png](output_111_0.png)


## Plotting with Matplotlib

This exercise was extracted from the Part 03 Lesson 02 Exercise 19.

### Q1: Do wines with higher alcoholic content receive better ratings?
Create a bar chart with one bar for low alcohol and one bar for high alcohol wine samples. This first one is filled out for you.

The strategy to this exercise is the same of the others:

* Finding the Median;
* Split the dataframe in two part (using the median);
* Compare the variable of interest (alcohol mean) of this two datasets;
* Make your analysis, and;
* Write your conclusion.

#### Finding the Median


```python
# Use query to select each group and get its mean quality
median = wine['alcohol'].median()

# Print
median
```




    10.3



#### Split the data frame in two


```python
# Alcohol is my variable of interest
low_alcohol = wine.query('alcohol < {}'.format(median))   # Wise way to do the filter the rows.
high_alcohol = wine.query('alcohol >= {}'.format(median)) # using the query()
```

#### Mean calculating


```python
# Subset the 'quality' column and calculate the mean
mean_quality_low = low_alcohol['quality'].mean()
mean_quality_high = high_alcohol['quality'].mean()
```

#### Make analysis

In this case a simple bar plot.


```python
# Create a bar chart with proper labels
locations = [1, 2]
heights = [mean_quality_low, mean_quality_high]
labels = ['Low', 'High']
plt.bar(locations, heights, tick_label=labels)
plt.title('Average Quality Ratings by Alcohol Content')
plt.xlabel('Alcohol Content')
plt.ylabel('Average Quality Rating');
```


![png](output_119_0.png)


#### Write your conclusion

Higher level of alcohol has better quality ratings.

### Q2: Do sweeter wines receive higher ratings?

Create a bar chart with one bar for low residual sugar and one bar for high residual sugar wine samples.

The **same** strategy:

* Finding the Median;
* Split the dataframe in two part (using the median);
* Compare the variable of interest (alcohol mean) of this two datasets;
* Make your analysis, and;
* Write your conclusion.

#### Finding the Median


```python
median_q2 = wine['residual_sugar'].median()
```

#### Split the data frame in two


```python
bottom = wine.query('residual_sugar < {}'.format(median_q2))
upper = wine.query('residual_sugar >= {}'.format(median_q2))
```

#### Mean calculating


```python
mean_bottom_q2 = bottom['quality'].mean()
mean_upper_q2 = upper['quality'].mean()
```

#### Make analysis

In this case a simple bar plot.


```python
# Create a bar chart with proper labels
locations = [1, 2]
heights = [mean_bottom_q2, mean_upper_q2]
labels = ['Low', 'High']
plt.bar(locations, heights, tick_label=labels)
plt.title('Average Quality Ratings by Residual Sugar')
plt.xlabel('Residual Sugar')
plt.ylabel('Average Quality Rating');
```


![png](output_128_0.png)


#### Write your conclusion

Higher level of residual sugar has (slightly) better quality ratings.


```python
print("Low Redisual Sugar: {} \nHigh Redisual Sugar: {}".format(round(mean_bottom_q2,2), round(mean_upper_q2,2)))
```

    Low Redisual Sugar: 5.81 
    High Redisual Sugar: 5.83
    

### Q3: What level of acidity receives the highest average rating?

Create a bar chart with a bar for each of the four acidity levels.

The step-by-step:

* Calculation of quartiles using the `.describe()` method;
* Definition of cuts;
* Definition of names;
* Create a column to create a category of acidity levels;
* Make Analysis (Plotting);
* Draw Conclusions.


```python
wine['ph'].describe()
```




    count    6497.000000
    mean        3.218501
    std         0.160787
    min         2.720000
    25%         3.110000
    50%         3.210000
    75%         3.320000
    max         4.010000
    Name: ph, dtype: float64




```python
# Bin edges that will be used to "cut" the data into groups
cuts_values = [2.72,3.11,3.21,3.32,4.01] # Fill in this list with five values you just found

# Labels for the four acidity level groups
cuts_names = ['high','mod_high','middle','low'] # Name each acidity level category

# Creates acidity_levels column
wine['acidity_levels'] = pd.cut(wine['ph'], cuts_values, labels=cuts_names)

# Checks for successful creation of this column
wine[['acidity_levels','ph','quality']].head(10) # First 9 rows filtered by pH and acidity_levels

# Use groupby to get the mean quality for each acidity level
heights = wine.groupby(['acidity_levels']).mean().quality

# Print
heights
```




    acidity_levels
    high        5.783343
    mod_high    5.784540
    middle      5.850832
    low         5.859593
    Name: quality, dtype: float64




```python
# Create a bar chart with proper labels
locations = [1, 2, 3, 4]
plt.bar(locations, heights, tick_label= cuts_names)
plt.title('Average Quality Ratings by Acidity Levels')
plt.xlabel('Acidity Levels')
plt.ylabel('Average Quality Rating');
```


![png](output_134_0.png)


Altering the sequence of bar, low first.


```python
# Create a bar chart with proper labels
locations = [4, 2, 3, 1]
plt.bar(locations, heights, tick_label= cuts_names)
plt.title('Average Quality Ratings by Acidity Levels')
plt.xlabel('Acidity Levels')
plt.ylabel('Average Quality Rating');
```


![png](output_136_0.png)

